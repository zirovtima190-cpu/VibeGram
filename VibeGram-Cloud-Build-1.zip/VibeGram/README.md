# VibeGram Android starter

Package: `com.vibegram.app`

## Build a real APK in the cloud (phone only)
1. Create a GitHub account if you do not already have one.
2. Create a new repository named `VibeGram` (Public or Private).
3. Upload the contents of this ZIP to the repository's `main` branch. Make sure `.github/workflows/build-apk.yml` is included. If the GitHub mobile upload page hides dot-folders, use the browser's desktop-site mode or create the workflow file in GitHub's web editor at `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab. Select **Build VibeGram APK** and tap **Run workflow** (or wait for the first push build).
5. When the run finishes successfully, open it, scroll to **Artifacts**, and download `VibeGram-debug-apk`.
6. Extract the artifact ZIP on your phone; inside is `app-debug.apk`. Tap it to install. Android may ask you to allow installs from that browser/file manager.

## What's in this first module
- Chat list UI with search
- Demo stories row
- Bottom navigation
- Demo conversation screen with local in-memory message bubbles
- Purple/pink dark theme

## Important limitations
This is a first UI prototype, not yet a full online messenger. The sample conversations are local demo data; messages are not sent to other people. Firebase authentication, Firestore messaging, media upload, push notifications, security rules, and end-to-end encryption still need to be implemented.

## Technical setup
- Kotlin + Jetpack Compose
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- JDK 17
- compileSdk 35, minSdk 24
