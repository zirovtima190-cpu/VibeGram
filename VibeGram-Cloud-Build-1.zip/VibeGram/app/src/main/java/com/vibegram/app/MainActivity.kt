package com.vibegram.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Deep = Color(0xFF171020)
private val Panel = Color(0xFF24182F)
private val Purple = Color(0xFF9B5DE5)
private val Pink = Color(0xFFF15BB5)
private val Muted = Color(0xFFB9AFC4)

data class Chat(
    val name: String,
    val message: String,
    val time: String,
    val initials: String,
    val unread: Int = 0,
    val online: Boolean = false
)

private val sampleChats = listOf(
    Chat("Алина", "Скинь фотки с вчера 💜", "14:32", "А", 2, true),
    Chat("Максим", "Ахах, договорились!", "13:58", "М", 0, true),
    Chat("VibeGram News", "Добро пожаловать в VibeGram!", "12:10", "V", 5),
    Chat("Друзья 🪩", "Кто сегодня гуляет?", "Вчера", "Д", 0),
    Chat("Саша", "Голосовое сообщение", "Вчера", "С", 0)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VibeGramApp() }
    }
}

@Composable
fun VibeGramApp() {
    var selectedTab by remember { mutableStateOf("Чаты") }
    var search by remember { mutableStateOf("") }
    var openedChat by remember { mutableStateOf<Chat?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            secondary = Pink,
            background = Deep,
            surface = Panel
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Deep) {
            if (openedChat != null) {
                ChatScreen(chat = openedChat!!, onBack = { openedChat = null })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Header()
                    Spacer(Modifier.height(18.dp))
                    SearchBox(search, { search = it })
                    Spacer(Modifier.height(18.dp))
                    StoriesRow()
                    Spacer(Modifier.height(18.dp))
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (selectedTab == "Чаты") "Сообщения" else selectedTab,
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(Icons.Default.Edit, null, tint = Pink)
                    }
                    Spacer(Modifier.height(10.dp))
                    val visible = sampleChats.filter {
                        it.name.contains(search, ignoreCase = true) ||
                            it.message.contains(search, ignoreCase = true)
                    }
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 12.dp)
                    ) {
                        items(visible) { chat ->
                            ChatRow(chat) { openedChat = chat }
                        }
                    }
                    BottomBar(selectedTab) { selectedTab = it }
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(Purple, Pink))),
            contentAlignment = Alignment.Center
        ) {
            Text("V", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("VibeGram", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text("Твой мир общения", color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.QrCodeScanner, null, tint = Color.White, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(16.dp))
        Icon(Icons.Default.MoreVert, null, tint = Color.White, modifier = Modifier.size(25.dp))
    }
}

@Composable
private fun SearchBox(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        placeholder = { Text("Поиск чатов", color = Muted) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Purple,
            unfocusedBorderColor = Panel,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = Pink,
            focusedContainerColor = Panel,
            unfocusedContainerColor = Panel
        )
    )
}

@Composable
private fun StoriesRow() {
    Row(
        Modifier.fillMaxWidth().padding(start = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        StoryBubble("＋", "Моя история", true)
        StoryBubble("А", "Алина")
        StoryBubble("М", "Максим")
        StoryBubble("С", "Саша")
        StoryBubble("Д", "Друзья")
    }
}

@Composable
private fun StoryBubble(initial: String, label: String, add: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(66.dp)) {
        Box(
            Modifier.size(58.dp).clip(CircleShape)
                .background(
                    if (add) Panel else Brush.linearGradient(listOf(Purple, Pink))
                ).padding(3.dp).clip(CircleShape).background(Deep),
            contentAlignment = Alignment.Center
        ) {
            Text(initial, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ChatRow(chat: Chat, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Box(
                Modifier.size(54.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Purple, Pink))),
                contentAlignment = Alignment.Center
            ) {
                Text(chat.initials, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            if (chat.online) {
                Box(Modifier.size(13.dp).clip(CircleShape).background(Color(0xFF42D392)))
            }
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(chat.message, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(chat.time, color = Muted, fontSize = 10.sp)
            if (chat.unread > 0) {
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier.clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Purple, Pink)))
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(chat.unread.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    val tabs = listOf(
        Triple("Чаты", Icons.Default.ChatBubble, "Чаты"),
        Triple("Контакты", Icons.Default.People, "Контакты"),
        Triple("Звонки", Icons.Default.Call, "Звонки"),
        Triple("Профиль", Icons.Default.Person, "Профиль")
    )
    Row(
        Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        tabs.forEach { (label, icon, key) ->
            Column(
                Modifier.weight(1f).clickable { onSelect(key) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, null, tint = if (selected == key) Pink else Muted)
                Text(label, color = if (selected == key) Pink else Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ChatScreen(chat: Chat, onBack: () -> Unit) {
    var message by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(listOf<String>()) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.ArrowBack, "Назад", tint = Color.White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(chat.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(if (chat.online) "в сети" else "был(а) недавно", color = Muted, fontSize = 11.sp)
            }
            Icon(Icons.Default.Call, null, tint = Pink)
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Default.MoreVert, null, tint = Color.White)
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
            Text(
                "Это начало вашей переписки в VibeGram 💜",
                color = Muted,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 18.dp)
            )
            sent.forEach {
                Text(
                    it,
                    color = Color.White,
                    modifier = Modifier.align(Alignment.End).padding(vertical = 4.dp)
                        .background(Brush.linearGradient(listOf(Purple, Pink)), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, null, tint = Pink, modifier = Modifier.padding(8.dp))
            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение...", color = Muted) },
                singleLine = true,
                shape = RoundedCornerShape(22.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = Deep,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Deep,
                    unfocusedContainerColor = Deep
                )
            )
            IconButton(onClick = {
                if (message.isNotBlank()) {
                    sent = sent + message.trim()
                    message = ""
                }
            }) {
                Icon(Icons.Default.Send, null, tint = Pink)
            }
        }
    }
}
